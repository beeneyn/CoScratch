let button = document.createElement('blocklive-init')
button.className = 'button_outlined-button_1bS__ menu-bar_menu-bar-button_3IDN0'
button.style.background = "#ff00e6"
button.style.background = ' linear-gradient(90deg, rgba(51,0,54,1) 0%, rgba(255,0,113,1) 60%)'
button.innerHTML = "Blocklive Collaborate"
document.querySelector('.menu-bar_main-menu_3wjWH').appendChild(button)
