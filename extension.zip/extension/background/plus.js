// chrome.runtime.storage.local.set({plus:false});


async function isPlus() {
    return Boolean((await chrome.runtime.storage.local.get('plus')).plus);
}
async function refreshIsPlus() {
    
}

